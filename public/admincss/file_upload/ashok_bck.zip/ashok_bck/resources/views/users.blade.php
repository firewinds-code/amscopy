@extends("layouts.masterlayout")
@section('title','Users')
@section('bodycontent')
<style>
	// Pager pagination
.my-active span{
	background: linear-gradient(to bottom,#fff 0,#dcdcdc 100%) !important;
	color: white !important;
	border-color: #5cb85c !important;
			
}

.pager {
  padding-left: 0;
  margin: 20px 0;
  text-align: right;
  list-style: none;
}
.pager li {
  display: inline;
}
.pager li > a,
.pager li > span {
  display: inline-block;
  padding: 5px 14px;
  background-color: #fff;
  border: 1px solid #ddd;
  /* border-radius: 15px; */
}
.pager li > a:hover,
.pager li > a:focus {
  text-decoration: none;
  background-color: #eee;
}
.pager .next > a,
.pager .next > span {
  float: right;
}
.pager .previous > a,
.pager .previous > span {
  float: left;
}
.pager .disabled > a,
.pager .disabled > a:hover,
.pager .disabled > a:focus,
.pager .disabled > span {
  color: #777;
  cursor: not-allowed;
  background-color: #fff;
}
.pager {
  padding-left: 0;
  margin: @line-height-computed 0;
  list-style: none;
  text-align: :right;
  &:extend(.clearfix all);
  li {
    display: inline;
    > a,
    > span {
      display: inline-block;
      padding: 5px 14px;
      background-color: @pager-bg;
      border: 1px solid @pager-border;
      border-radius: @pager-border-radius;
    }

    > a:hover,
    > a:focus {
      text-decoration: none;
      background-color: @pager-hover-bg;
    }
  }

  .next {
    > a,
    > span {
      float: right;
    }
  }

  .previous {
    > a,
    > span {
      float: left;
    }
  }

  .disabled {
    > a,
    > a:hover,
    > a:focus,
    > span {
      color: @pager-disabled-color;
      background-color: @pager-bg;
      cursor: @cursor-disabled;
    }
  }
}
</style>
	<div class="content-wrapper mobcss">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Manage Users</h4>
                <div class="row">
                    <div class="col-md-12">
                    	<div id="insertusers" >
							<form name="myForm" method="post" enctype="multipart/form-data" action="{{url('store-users')}}" onsubmit="return usersFormValidation()">
	                        	<input type="hidden" name="_token" value="{{csrf_token()}}">
	                        	<input type="hidden" name="dataid" id="dataid">
	                        	<input type="hidden" name="userTypeId" id="userTypeId">
								<div class="row">
									<div class="form-group col-md-3">
										<label for="usertype_id">User Type</label>
										<span style="color: red;">*</span>
										<select name="usertype_id" id="usertype_id" tabindex="1" class="form-control" onchange="fn_user_type_change(this,'');">
											<option Value="NA">--select--</option>
											@isset($roleUserTypeData)
												@foreach($roleUserTypeData as $row)
													<option Value="{{$row->id}}">{{$row->usertype}}</option>
												@endforeach
											@endisset
										</select>
										<span id="usertype_id_error" style="color:red"></span>
									</div>
									<div class="form-group col-md-3">
										<label for="Name">First Name</label>
										<span style="color: red;">*</span>
										<input type="text" name="name" id="name" class="form-control" placeholder="Name">
										<span id="name_error" style="color:red"></span>
									</div>
									<div class="form-group col-md-3">
										<label for="Name">Lastname</label>
										<input type="text" name="last_name" id="last_name" class="form-control" placeholder="Lastname">
										<span id="last_name_error" style="color:red"></span>
									</div>
									<div class="form-group col-md-3" id="td_employee_id">
										<label for="Name">Employee Id</label>
										<span style="color: red;">*</span>
										<input type="text" name="employee_id" id="employee_id" class="form-control" placeholder="Employee Id">
										<span id="employee_id_error" style="color:red"></span>
									</div>
									<div class="form-group col-md-3">
										<label for="Name">Mobile</label> <span style="color: red;">*</span>
										<input type="text" name="phonenumbers" id="phonenumbers" onblur="fn_mob_change(this)" class="form-control" placeholder="Mobile" >
										<span id="mobile_error" style="color:red"></span> 
									</div>
									<div class="form-group col-md-3">
										<label for="Name">Role</label>
										<span style="color: red;">*</span>
										<select name="role" id="role" class="form-control">
												<option value="NA">--Select--</option>
										</select>
										<span id="role_error" style="color:red"></span>
									</div>
									<div class="form-group col-md-3">
										<label for="Name">Email</label> <span style="color: red;">*</span>
										<input type="email" name="email" id="email" class="form-control" placeholder="Email">
										<span id="email_error" style="color:red"></span> 
									</div> 
									<div class="form-group col-md-3">
										<label for="Name">Password</label> <span style="color: red;">*</span>
										<input type="password" name="password" id="password" class="form-control" placeholder="Password">
										<span id="password_error" style="color:red"></span> 
									</div>
									<div class="form-group col-md-3" id="td_dealer_id" style="display: none;">
										<label for="Name">Dealer Name</label> <span style="color: red;">*</span>
										<select name="dealer_id" id="dealer_id" tabindex="1" class="form-control">
												<option Value="NA">--select--</option>
												@isset($dealerData)
													@foreach($dealerData as $row)
														<option Value="{{$row->id}}">{{$row->dealer_name}}</option>
													@endforeach
												@endisset
										</select>
										<span id="dealer_code_error" style="color:red"></span> 
									</div> 
									<div class="form-group col-md-3" id="td_zone" style="display: none;">
										<label for="Zone">Zone</label>
										<span style="color: red;">*</span>
										<select name="zone[]" id="zone" multiple class="form-control" onchange="Dealer_Zone_change(this.value,'')">
											@isset($regionData)
												@foreach($regionData as $regionRow)
													<option value="{{$regionRow->id}}">{{$regionRow->region}}</option>
												@endforeach
											@endisset
										</select>
										<span id="Zone_error" style="color:red"></span>
									</div>
									<div class="form-group col-md-3" id="td_State" style="display: none;">
										<label for="State" >Region</label> <span style="color: red;">*</span>
										<select name="state[]" multiple id="state" class="form-control" onchange="Dealer_State_change(zone,this.value,'');"></select>
										<span id="State_error" style="color:red"></span> 
									</div>
									<div class="form-group col-md-3" id="td_City" style="display: none;">
										<label for="City">Area</label> <span style="color: red;">*</span>
										<select name="City[]" multiple id="City" class="form-control" onchange="cityChangeGetDealer(zone,state,this.value,'');">
											<option value="NA">--Select--</option>
										</select>
										<span id="City_error" style="color:red"></span> 
									</div>
									<div class="form-group col-md-3" id="td_dealer_id1" style="display: none;">
										<label for="Name">Dealer Name</label> <span style="color: red;">*</span>
										<select name="dealer_id_arr[]" multiple id="dealer_id1" tabindex="1" class="form-control">
												<option Value="NA">--select--</option>
										</select>
									</div> 
									
								</div>
								@if(Session::get('role') == '29' || Session::get('role') == '30')
	                            <div class="box-footer">
	                                <span class="pull-right">
									<button type="button" onclick="reloadPage();" class="btn-secondary">Cancel</button>	
	                                <input type="submit"name="submit" id="submit" value="Submit" class="btn-secondary">
	                                </span>
	                            </div>
								@endif
	                        </form>
						</div>
                        <div class="clear"></div>
                        <hr>
						<div class="row">
							<div class="col-md-5"><a class="btn btn-warning" href="{{ route('exportUser') }}" style="background-color: #e9e9e9;border: 1px solid #999;border-radius: 2px;">Excel</a></div>
							<div class="col-md-4"></div>
							<div class="col-md-3 col-md-offset-3">
							<input type="text" name="SearchVicle" id="SearchVicle" class="form-control" placeholder="Search" autocomplete="off"/>
							</div>
						</div>
                        <div class="table-responsive">
                            <table id="order-listing1" class="table" data-order='[[ 0, "desc" ]]' data-page-length='10'>
                                <thead>
                                    <tr>
                                    	<th class="d-none">id</th>	
                                    	<th class="d-none">last_name</th>	
                                    	<th class="d-none">User Id</th>	
                                    	<th class="d-none">UserType ID</th>	
                                    	<th class="d-none">Email</th>
										<th class="d-none">State</th>
										<th class="d-none">Region</th>
										<th class="d-none">City</th>
										<th class="d-none">Role_id</th>
										<th class="d-none">Dealer Id</th>
										<th>Actions</th>
										<th>Employee Id</th>
										<th>Name</th>
										<th>User Type</th>
										<th>Role</th>
										<th>Mobile</th>
                                    </tr>
                                </thead>
                                <tbody id="tableDisabled">
									@isset($rowData)
										@php $count=1; @endphp
										@foreach($rowData as $row)
										<tr>
											<td class="d-none">{{$row->id}}</td>	
											<td class="cls_last_name d-none">{{$row->last_name}}</td>	
											<td class="cls_username d-none">{{$row->name}}</td>	
											<td class="cls_usertype_id d-none">{{$row->user_Type_id}}</td>	
											<td class="cls_email d-none">{{$row->email}}</td>
											<td class="cls_state d-none">{{$row->state}}</td>
											<td class="cls_zone d-none">{{$row->zone}}</td>
											<td class="cls_city d-none">{{$row->city}}</td>	
											<td  class="cls_roleName d-none">{{$row->role}}</td>
											<td class="cls_dealer_id d-none">{{$row->dealer_id}}</td>
											<td>
												<i class="fa fa-pencil-square-o" aria-hidden="true" id="{{$row->id}}" data-position="left" data-tooltip="Edit" onclick="javascript:return editUser(this);" style="cursor: pointer;"></i>
												<a href="{{route('users_delete.usersDelete', ['id' => $row->id])}}" onclick="return confirm('Do you want to delete?')">
													<i class="fa fa-trash-o" aria-hidden="true" style="cursor: pointer;"></i></a>
											</td>
											<td class="cls_employee_id">{{$row->employee_id}}</td>
											<td class="cls_name">{{$row->name}}</td>
											<td class="cls_usertype">{{$row->usertype}}</td>
											<td>{{$row->role_name}}</td>
											<td class="cls_mobile">{{$row->mobile}}</td>
										</tr>
										@php $count++; @endphp	
										@endforeach
									@endisset
                                </tbody>
								<div>
									<tbody id="tableEnabled"></tbody>
								</div>
                            </table>
                        </div>
						{{ $rowData->links('pagination.custom') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
 <script>
	  $(document).ready(function () {
		$("#SearchVicle").keyup(function(){
			var inptData = $(this).val();
			$.ajax({
				url: '{{url("ajax-user-report-data")}}',
				data: {'keyword':inptData},
				success: function(data){
					console.log(data);
					$("#tableDisabled").hide();
					$("#tableEnabled").show();
					$("#tableEnabled").html(data);
					$("#SearchVicle").css("background","#FFF");
				}
			});
		});
		$('#purchase_date').datetimepicker({ format:'Y-m-d',timepicker:false});
		$('#order-listing1').DataTable({
				dom: 'Bfrtip',
				"paging":   false,
				"searching": false,
				"language": {
					"paginate": {
						"previous": "<",
						"next": ">"
					}
				}/* ,
				buttons: [
					{
						extend: 'excel',
						text: 'Excel',
						className: 'exportExcel',
						filename: '@yield("title")',
						exportOptions: { modifier: { page: 'all'} }
					}
				] */
			});
	});
 function fn_mob_change(el){
	var dataid = $('#dataid').val();
 	if(dataid ==''){
 		var mob = el.value;
	 	$.ajax({
			url:'{{url("check-mobile-duplicate")}}',
			data:{"mob":mob},
			success:function(result) {
				if(result =='not'){
					document.getElementById("mobile_error").innerHTML= '';
				}else{
					document.getElementById("mobile_error").innerHTML= result;
				}
			}
		});
 	}else{
 		var mob = el.value;
	 	$.ajax({
			url:'{{url("check-mobile-duplicate")}}',
			data:{"mob":mob,"userId":dataid},
			success:function(result) {
				if(result =='not'){
					document.getElementById("mobile_error").innerHTML= '';
				}else{
					document.getElementById("mobile_error").innerHTML= result;
				}
			}
		});
 	}
 }
function editUser(el){
	$('#dataid').val(el.id);
	var state =$(el).parents('td').parents('tr').find('.cls_state').text();
	var city =$(el).parents('td').parents('tr').find('.cls_city').text();
	var zone =$(el).parents('td').parents('tr').find('.cls_zone').text();
	var employee_id =$(el).parents('td').parents('tr').find('.cls_employee_id').text();
	
	var name =$(el).parents('td').parents('tr').find('.cls_name').text();
	var last_name =$(el).parents('td').parents('tr').find('.cls_last_name').text();
	var email =$(el).parents('td').parents('tr').find('.cls_email').text();
	var usertype_id =$(el).parents('td').parents('tr').find('.cls_usertype_id').text();
	var roleName =$(el).parents('td').parents('tr').find('.cls_roleName').text();
	var dealer_id =$(el).parents('td').parents('tr').find('.cls_dealer_id').text();
	var mobile =$(el).parents('td').parents('tr').find('.cls_mobile').text();
	var username ='';
	if (dealer_id.indexOf(',') > -1 || state.indexOf(',') > -1 || city.indexOf(',') > -1 || zone.indexOf(',') > -1 || usertype_id !=3) {
		$('#dealer_id').val('');
		
		cityChangeGetDealer(zone,state,city,dealer_id);
	}else{
		$('#zone').val('');
		$('#state').val('');
		$('#City').val('');
		$('#dealer_id1').val('');
		fn_get_dealer_user(dealer_id);
	}
	
	fn_user_type_change(usertype_id,roleName);
	if(usertype_id !=3){
		Dealer_get_zone(zone);
		Dealer_Zone_change(zone,state);
		Dealer_State_change(zone,state,city);
	 }
	 $('#employee_id').val(employee_id);
	 $('#role').val(roleName);	  
	 $('#name').val(name);
	 $('#last_name').val(last_name);
	 $('#email').val(email);
	 $('#password').val('*******');
	 $('#password').attr('disabled','disabled');
	  $('#usertype_id').attr('disabled','disabled');
	 $('#userTypeId').val(usertype_id);
	 $('#usertype_id').val(usertype_id);
	 $('#phonenumbers').val(mobile);
}

 </script>
<script>
	function Dealer_State_change(el,ell,elll){
		var favorite = [];
		var AllZone_ = [];
		var AllState_ = [];
		if(elll!=''){
			AllZone = el;
			AllState=ell;
		}else{
			$('#zone :selected').each(function(i, sel){ 
				AllZone_.push($(this).val());
			});
			var AllZone = AllZone_.join(',');
			$('#state :selected').each(function(i, sel){ 
				AllState_.push($(this).val());
			});
			var AllState = AllState_.join(',');
		}
		$.ajax({ url: '{{url("get-multi-id-city")}}',
			data: { 'r_id':AllZone,'s_id':AllState },
			success: function(data){		
			var Result = data.split(",");var str = '';
			Result.pop();
			for (item in Result){	
				Result2 = Result[item].split("~");
				var mith = elll.split(",");
				if(elll!=''){
					if (jQuery.inArray(Result2[0], mith)!='-1'){
						str += "<option value='" + Result2[0] + "' selected>" + Result2[1] + "</option>";	
					}else{
						str += "<option value='" + Result2[0] + "'>" +Result2[1] + "</option>";		
					}	
				}else{
					str += "<option value='" + Result2[0] + "'>" + Result2[1] + "</option>";			
				}
			}
			document.getElementById('City').innerHTML = str;
		}});
	}
	function cityChangeGetDealer(el,ell,elll,ellll){
			
		var favorite = [];
		var AllZone_ = [];
		var AllState_ = [];
		var AllCity_ = [];
		if(ellll!=''){
			AllZone = el;
			AllState=ell;
			AllCity=elll;
		}else{
			$('#zone :selected').each(function(i, sel){ 
				AllZone_.push($(this).val());
			});
			var AllZone = AllZone_.join(',');
			$('#state :selected').each(function(i, sel){ 
				AllState_.push($(this).val());
			});
			var AllState = AllState_.join(',');
			$('#City :selected').each(function(i, sel){ 
				AllCity_.push($(this).val());
			});
			var AllCity = AllCity_.join(',');
		}
		$.ajax({ url: '{{url("city-change-get-dealer")}}',
			data: { 'r_id':AllZone,'s_id':AllState,'c_id':AllCity },
			success: function(data){
				console.log(data);
			var Result = data.split(",");var str = '';
			Result.pop();
			for (item in Result){	
				Result2 = Result[item].split("~");
				var checkVar = ellll.split(",");
				if(ellll!=''){
					if (jQuery.inArray(Result2[0], checkVar)!='-1'){
						str += "<option value='" + Result2[0] + "' selected>" + Result2[1] + "</option>";	
					}else{
						str += "<option value='" + Result2[0] + "'>" +Result2[1] + "</option>";		
					}	
				}else{
					str += "<option value='" + Result2[0] + "'>" + Result2[1] + "</option>";
				}
			}
			document.getElementById('dealer_id1').innerHTML = str;
		}});
	}
	function Dealer_get_zone(ell){
		$.ajax({ url: '{{url("get-multi-zone")}}',
			 success: function(data) {
				 var Result = data.split(",");var str = '';
				 Result.pop();				 
				 for (item in Result){
				  	Result2 = Result[item].split("~");
				  	
					var mith = ell.split(",");					
					if (ell!=''){
			  			if (jQuery.inArray(Result2[0], mith)!='-1')
						{
							$('#zone').val(mith);
						}
					}
				 }
			 }
		 });
	} 
</script> 
@endsection
