@extends("layouts.masterlayout")
@section('title','Not Autherized')
@section('bodycontent')
	<div class="content-wrapper">
        <div class="card">
            <div class="card-body">                
                <div class="row">
                    <div class="col-md-12">
                    	<h2>You are not autherized.</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
