<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use Session;
use Redirect;
use Mail;
use App\classes\ServerValidation;
use App\classes\AccessControl;
date_default_timezone_set('Asia/Kolkata');
class CronJobController  extends Controller{
	
	public function caseCreationMail(){
		$mailDetails = DB::table("cronjob_mail")->select('id', 'subject', 'body', 'toMail', 'ccMail', 'reporting_manager', 'customer_mail_id','complaint_receiver','case_owner_email','flag')->where('flag','0')->where('case_status','create')->get();
		foreach($mailDetails as $mailRow){
			$id = $mailRow->id;
			$subject = $mailRow->subject;
			$body = $mailRow->body;
			$toMail = $mailRow->toMail;
			$reporting_manager = $mailRow->reporting_manager;
			$ccMail = $mailRow->ccMail;
			$customer_mail_id = $mailRow->customer_mail_id;
			$complaint_receiver = $mailRow->complaint_receiver;
			$complaint_receiver = $complaint_receiver !=''?$complaint_receiver:'select.support@ashokleyland.com';
			$case_owner_email = $mailRow->case_owner_email;
			$case_owner_email = $case_owner_email !=''?$case_owner_email:'select.support@ashokleyland.com';
			$flag = $mailRow->flag;
			$currentDate = date('Y-m-d H:i:s');
			$data=['body'=>$body];			
			$allCCMailAr='';			
			$allCCMail =  trim($reporting_manager).",".trim($complaint_receiver);
			$allCCMailAr = explode(',',$allCCMail);
			//var_dump($allCCMailAr);die;
			Mail::send('assigned_email',["data"=>$data],function ($message) use ($toMail,$case_owner_email,$subject,$allCCMailAr) {
				$message->to([$toMail,$case_owner_email])->cc($allCCMailAr)->subject($subject);			
				$message->from('select.support@ashokleyland.com');
			});
			
			DB::table('cronjob_mail')->where('id', $id)->update(['flag' => '1','updated_at'=>"$currentDate"]);
			
		}
	}
	public function caseUpdationMail(){
		$mailDetails = DB::select("select id, subject, body, toMail, ccMail, reporting_manager, flag, complaint_receiver,case_owner_email from cronjob_mail where flag = 0 and (case_status='update' or case_status='Acknowledged' or case_status='Assigned' or case_status='InProgress' or case_status='Waiting for Customer' or case_status='tobedropped')");
		
		foreach($mailDetails as $mailRow){
			$id = $mailRow->id;
			$subject = $mailRow->subject;
			$body = $mailRow->body;
			$toMail = $mailRow->toMail;
			$reporting_manager = $mailRow->reporting_manager;
			$ccMail = $mailRow->ccMail;
			$flag = $mailRow->flag;
			$complaint_receiver = $mailRow->complaint_receiver;
			$case_owner_email = $mailRow->case_owner_email;
			$case_owner_email = $case_owner_email !=''?$case_owner_email:'select.support@ashokleyland.com';
			$complaint_receiver = $complaint_receiver !=''?$complaint_receiver:'select.support@ashokleyland.com';
			$currentDate = date('Y-m-d H:i:s');
			$data=['body'=>$body];
			$ccMailAr = '';
			$ccMailAr = explode(',',$ccMail);
			Mail::send('assigned_email',["data"=>$data],function ($message) use ($toMail,$ccMailAr,$reporting_manager,$complaint_receiver,$case_owner_email,$subject) {
				$message->to([$toMail,$reporting_manager,$complaint_receiver])->cc($case_owner_email)->subject($subject);			
				$message->from('select.support@ashokleyland.com');
			});
			
			DB::table('cronjob_mail')->where('id', $id)->update(['flag' => '1','updated_at'=>"$currentDate"]);
		}
	}
	public function caseClosedMail(){
		//DB::enableQueryLog();
		$mailDetails = DB::table("cronjob_mail")->select('id', 'subject', 'body', 'toMail', 'ccMail', 'reporting_manager', 'flag', 'complaint_receiver', 'case_owner_email')->where('flag','0')->where('case_status','closed')->orwhere('case_status','Completed')->get();
		//$query = DB::getQueryLog();
		//dd($query);
		foreach($mailDetails as $mailRow){
			$id = $mailRow->id;
			$subject = $mailRow->subject;
			$body = $mailRow->body;
			$toMail = $mailRow->toMail;
			$reptMangerMail = $mailRow->reporting_manager;
			$reporting_manager = $reptMangerMail !=''?$reptMangerMail:'select.support@ashokleyland.com';
			$complaint_receiver = $mailRow->complaint_receiver;
			$complaint_receiver = $complaint_receiver !=''?$complaint_receiver:'select.support@ashokleyland.com';
			$case_owner_email = $mailRow->case_owner_email;
			$case_owner_email = $case_owner_email !=''?$case_owner_email:'select.support@ashokleyland.com';
			$complaint_receiver = $complaint_receiver !=''?$complaint_receiver:'select.support@ashokleyland.com';
			$ccMail = $mailRow->ccMail;
			$flag = $mailRow->flag;
			$currentDate = date('Y-m-d H:i:s');
			$data=['body'=>$body];
			$ccMailAr = '';
			$ccMailAr = explode(',',$ccMail);
			Mail::send('assigned_email',["data"=>$data],function ($message) use ($toMail,$case_owner_email,$complaint_receiver,$reporting_manager,$subject) {
				$message->to([$toMail,$reporting_manager,$complaint_receiver])->cc($case_owner_email)->subject($subject);			
				$message->from('select.support@ashokleyland.com');;
			});
			DB::table('cronjob_mail')->where('id', $id)->update(['flag' => '1','updated_at'=>"$currentDate"]);
		}
	}
	public function caseReOpen(){
		$mailDetails = DB::table("cronjob_mail")->select('id', 'subject', 'body', 'toMail', 'ccMail', 'reporting_manager', 'customer_mail_id','complaint_receiver','case_owner_email','flag')->where('flag','0')->where('case_status','reopen')->get();
		foreach ($mailDetails as $mailRow) {
			$id = $mailRow->id;
			$subject = $mailRow->subject;
			$body = $mailRow->body;
			$toMail = $mailRow->toMail;
			$reporting_manager = $mailRow->reporting_manager;
			$ccMail = $mailRow->ccMail;
			$customer_mail_id = $mailRow->customer_mail_id;
			$complaint_receiver = $mailRow->complaint_receiver;
			$complaint_receiver = $complaint_receiver !=''?$complaint_receiver:'select.support@ashokleyland.com';
			$case_owner_email = $mailRow->case_owner_email;
			$case_owner_email = $case_owner_email !=''?$case_owner_email:'select.support@ashokleyland.com';
			$flag = $mailRow->flag;
			$currentDate = date('Y-m-d H:i:s');
			$data=['body'=>$body];
			$allCCMailAr='';
			$allCCMail =  trim($reporting_manager).",".trim($complaint_receiver);
			$allCCMailAr = explode(',',$allCCMail);
			//var_dump($allCCMailAr);die;
			Mail::send('assigned_email',["data"=>$data],function ($message) use ($toMail, $case_owner_email, $subject, $allCCMailAr) {
				$message->to([$toMail,$case_owner_email])->cc($allCCMailAr)->subject($subject);
				$message->from('select.support@ashokleyland.com');
			});
			
			DB::table('cronjob_mail')->where('id', $id)->update(['flag' => '1','updated_at'=>"$currentDate"]);

		}
	} 
	
	public function autoEscalate(){
		//DB::enableQueryLog();
		/* $rowQuery = DB::table("cases")->select('id', 'complaint_number', 'vehicleId', 'ownerId', 'customer_contact_id', 'callerId', 'from_where', 'to_where', 'highway', 'ticket_type', 'aggregate', 'vehicle_problem', 'assign_to', 'dealer_mob_number', 'dealer_alt_mob_number', 'remark_type', 'disposition', 'agent_remark', 'standard_remark', 'assign_remarks', 'estimated_response_time', 'tat_scheduled', 'acceptance', 'latitude', 'longitude','created_at')->where('remark_type','!=','Work Completed')->where('remark_type','!=','Customer Confirmation Due')->where('remark_type','!=','Customer Confirmation Completed')->where('remark_type','!=','Customer Feedback')->where('remark_type','!=','Ticket Closed')->orderby('id','desc')->get(); */
		$rowQuery =DB::select("select id, complaint_number, vehicleId, ownerId, customer_contact_id, callerId, from_where, to_where, highway, ticket_type, 
		 vehicle_problem, assign_to, dealer_mob_number, dealer_alt_mob_number, remark_type, disposition, agent_remark,
		standard_remark, assign_remarks, estimated_response_time, tat_scheduled, acceptance, latitude, longitude,created_at from 
		cases where  remark_type  not in ('Work Completed','Customer Confirmation Due', 'Customer Confirmation Completed', 'Customer Feedback','Ticket Closed','Closed' ,'Completed') and complaint_number <>'' order by id desc");
		//dd($rowQuery);
		//$query = DB::getQueryLog();
		//dd($query);
		$maxLevelSql = DB::select("Select id,level, level_name, to_role, cc_role, hours, created_at, updated_at from mstr_escalations order by id desc");
		$maxLevel = $maxLevelSql[0]->level;
		/* foreach($rowQuery as $row){
			$complaint_number = $row->complaint_number;
			$escLevelSql = DB::select("Select id,levels, complaint_number from escaltion_levels where complaint_number='$complaint_number'");
			$level = $escLevelSql[0]->id.'****'.$escLevelSql[0]->levels.'****'.$complaint_number;
			echo $level.'<br>';
		}
		die; */
		foreach($rowQuery as $row){
			$id = $row->id;
			$complaint_number = $row->complaint_number;
			$vehicleId = $row->vehicleId;
			$emsnTypeSql = DB::select("Select engine_emmission_type from mstr_vehicle where id='$vehicleId'");
			$engine_emmission_type =  (sizeof($emsnTypeSql)>0 && $emsnTypeSql[0]->engine_emmission_type!='')?$emsnTypeSql[0]->engine_emmission_type:'NA';
			$assign_to = $row->assign_to;
			$created_at = $row->created_at;
			$escLevelSql = DB::select("Select levels, complaint_number from escaltion_levels where complaint_number='$complaint_number'");
			$level='';
			if(sizeof($escLevelSql)>0){
				$level = $escLevelSql[0]->levels;
			}
			
			$query = DB::select("select c.id as caseId, c.complaint_number, c.vehicleId, c.ownerId, c.customer_contact_id, c.callerId, c.from_where, c.to_where, c.highway, c.ticket_type, c.vehicle_problem, c.assign_to, c.dealer_mob_number, c.dealer_alt_mob_number, c.remark_type, c.disposition, c.agent_remark, c.standard_remark, c.assign_remarks, c.estimated_response_time, c.actual_response_time, c.tat_scheduled, c.acceptance, c.latitude, c.longitude,c.feedback_rating,c.feedback_desc,c.location,c.landmark,c.state as stateId,c.city as cityId,c.district,c.created_at, c.vehicle_type, v.vehicle, v.vehicle_model, v.reg_number, v.chassis_number, v.engine_number, v.vehicle_segment, v.purchase_date, v.add_blue_use, v.engine_emmission_type, o.owner_name, o.owner_mob, o.owner_landline, o.owner_cat, o.owner_company, oc.contact_name, oc.mob,oc.owner_contact_email,cal.caller_type, cal.caller_name, cal.caller_contact, cal.vehicle_movable, s.state, city.city,group_concat(rem.assign_remarks order by rem.id desc separator '@@') as assign_remark_log,group_concat(rem.created_at order by rem.id desc separator '@@') as assign_remark_date_log from cases as c left join mstr_vehicle as v on v.id = c.vehicleId left join mstr_owner as o on o.id = c.ownerId  and o.id = c.ownerId left join mstr_owner_contact as oc on oc.id = c.customer_contact_id and oc.vehicle_id = c.vehicleId and oc.owner_id = c.ownerId left join mstr_caller as cal on cal.id = c.callerId  and cal.owner_id = c.ownerId  left join mstr_caller_state as s on s.id = c.state left join mstr_caller_city as city on city.id = c.city left join remarks as rem on rem.complaint_number = c.complaint_number  where c.complaint_number = '$complaint_number'");
					$regNo =$query[0]->reg_number;
					$location =$query[0]->location;
					$db_estimated_response_time = $query[0]->estimated_response_time;
					$db_tat_scheduled = $query[0]->tat_scheduled;
					$db_contact_name = $query[0]->contact_name;
					$db_contact_mob = $query[0]->mob;
					$db_owner_name = $query[0]->owner_name;
					$db_owner_company = $query[0]->owner_company;
					$db_owner_mob = $query[0]->owner_mob;
					$db_assign_to = $query[0]->assign_to;
					$db_dealer_mob_number = $query[0]->dealer_mob_number;
					$db_dealer_alt_mob_number = $query[0]->dealer_alt_mob_number;
					$db_disposition = $query[0]->disposition;
					$db_agent_remark = $query[0]->agent_remark;
					$db_highway = $query[0]->highway;
					$db_city = $query[0]->city;
					$db_vehicle_model = $query[0]->vehicle_model;
					$db_chassis_number = $query[0]->chassis_number;
					$db_vehicle_type = $query[0]->vehicle_type;
					$db_created_at = $query[0]->created_at;
					$db_caller_name = $query[0]->caller_name;
					$db_caller_type = $query[0]->caller_type;
					$db_caller_contact = $query[0]->caller_contact;
					
					$db_acceptance = $query[0]->acceptance;
					$db_feedback_desc = $query[0]->feedback_desc;
					$db_feedback_rating = $query[0]->feedback_rating;
					$db_engine_emmission_type = $query[0]->engine_emmission_type;
					$ticetId = $query[0]->caseId;
					$assign_remark_log = explode("@@",$query[0]->assign_remark_log);
			 		$assign_remark_date_log = explode("@@",$query[0]->assign_remark_date_log);
			
			if($level <= $maxLevel && $level!=''){
				$level = $level+1;
				//echo "Select id, level_name, to_role, cc_role, hours, created_at, updated_at from mstr_escalations where level =$level";die;
				$matrix = DB::select("Select id, level_name, to_role, cc_role, hours, created_at, updated_at from mstr_escalations where level =$level");
				$hours = $matrix[0]->hours;
				$level_name = $matrix[0]->level_name;
				$addTime = date('Y-m-d H:i:s',strtotime('+'.$hours.' hour',strtotime($created_at)));
				$currentDateTime = date('Y-m-d H:i:s');
				//dd($addTime);	
				//dd(var_dump($currentDateTime > $addTime));
				if($currentDateTime > $addTime){
					$to_role = $matrix[0]->to_role;
					$cc_role = $matrix[0]->cc_role;
					if($engine_emmission_type == 'BS6'){
						$cc_role =$cc_role.',91';
					}
					//echo "Select email,name from users where role in ($to_role) and FIND_IN_SET($assign_to, dealer_id)";die;
					$toUsersSql =  DB::select("Select email,name from users where role in ($to_role) and FIND_IN_SET($assign_to, dealer_id)");
					$ccUserSql =   DB::select("Select email,name from users where role in ($cc_role) and FIND_IN_SET($assign_to, dealer_id)");
					//dd("Select email,name from users where role in ($cc_role) and dealer_id in ($assign_to)");
					$toUserArr=$ccUserArr ='';
					if(sizeof($toUsersSql)>0){
						foreach($toUsersSql as $row){
							//$toUserArr .= $row->email.",";
							if($row->email!=''){
								$toUser = trim($row->email);
								$toUser = str_replace(":",",",$toUser);
								$toUser = str_replace(";",",",$toUser);
								$toUser = str_replace(" ",",",$toUser);
								$toUserArr .= $toUser.",";
							}
						}
						$toUserArr = rtrim($toUserArr,',');
						$toUserArr = explode(",",$toUserArr);
					}else{
						$toUserArr = array("test@dispostable.com");
					}
					if(sizeof($ccUserSql)>0){
						foreach($ccUserSql as $row){
							//$ccUserArr .= $row->email.",";
							if($row->email!=''){
								$ccUser = trim($row->email);
								$ccUser = str_replace(":",",",$ccUser);
								$ccUser = str_replace(";",",",$ccUser);
								$ccUser = str_replace(" ",",",$ccUser);
								$ccUserArr .= $ccUser.",";
								//$ccUserArr[] = $row->email.",";
							}
						}
						$ccUserArr = rtrim($ccUserArr,',');
						$ccUserArr = explode(",",$ccUserArr);
					}else{
						$ccUserArr = array("test@dispostable.com");
					}
					
					
					//dd($ccUserArr);
					//$toReceiver = $toUsersSql[0]->name;
					$levNameArr = explode(" ",$level_name);
					$levName = $levNameArr[0];

					


					$supportContPersonSql = DB::select("Select mobile,name from users where role =76 and FIND_IN_SET($assign_to, dealer_id)");
					$supportContPerson = sizeof($supportContPersonSql)>0?$supportContPersonSql[0]->name:'NA';
					$supportContPersonMob = sizeof($supportContPersonSql)>0?$supportContPersonSql[0]->mobile:'NA';

					$subjct1 ="SELECT Ticket Details-Above $levName Hrs $complaint_number";
					$subjct2 ="BSVI SELECT Ticket Details-Above $levName Hrs $complaint_number";
					$subject=$engine_emmission_type=='BS6'?$subjct2:$subjct1;
					$body = '<p>Dear Team, </p>
					<p>Please find the below mentioned Break Down Details</p>
					<p>Kindly update the Response, Restoration and closure details by using Dealer Portal using the link. </p>
					<table border="1" style="font-family: sans-serif;">
				<tr>
					<td style=" text-align: left;">Customer Name</td>
					<td style="text-align: left;">'.$db_owner_company.'</td>
					
				</tr>
				<tr>
					<td style=" text-align: left;">Ticket Number</td>
					<td style="text-align: left;"><a href="'.url('update-case',['id' =>$ticetId]).'" >'.$complaint_number.'</a></td>		
					
				</tr>
				<tr>
					<td style=" text-align: left;">Breakdown Location</td>
					<td style="text-align: left;">'.$location.'</td>		
					
				</tr>
				<tr>
					<td style=" text-align: left;">NH</td>
					<td style="text-align: left;">'.$db_highway.'</td>		
					
				</tr>
				<tr>
					<td style=" text-align: left;">AO</td>
					<td style="text-align: left;">'.$db_city.'</td>		
					
				</tr>
				<tr>
					<td style=" text-align: left;">Registration Number</td>
					<td style="text-align: left;">'.$regNo.'</td>
					
				</tr>
				<tr>
					<td style=" text-align: left;">Vehicle Model</td>
					<td style="text-align: left;">'.$db_vehicle_model.'</td>
					
				</tr>
				<tr>
					<td style=" text-align: left;">Chassis Number</td>
					<td style="text-align: left;">'.$db_chassis_number.'</td>
					
				</tr>
				<tr>
					<td style=" text-align: left;">Vehicle Type</td>
					<td style="text-align: left;">'.$db_vehicle_type.'</td>
					
				</tr>
				<tr>
					<td style=" text-align: left;">Call Log Date</td>
					<td style="text-align: left;">'.date("d-m-Y",strtotime($db_created_at)).'</td>
					
				</tr>
				<tr>
					<td style=" text-align: left;">Call Log Time</td>
					<td style="text-align: left;">'.date("H:i:s",strtotime($db_created_at)).'</td>					
				</tr>
				<tr>
					<td style=" text-align: left;">Caller Name</td>
					<td style="text-align: left;">'.$db_caller_name.'</td>					
				</tr>
				<tr>
					<td style=" text-align: left;">Caller Type</td>
					<td style="text-align: left;">'.$db_caller_type.'</td>					
				</tr>
				<tr>
					<td style=" text-align: left;">Caller Contact</td>
					<td style="text-align: left;">'.$db_caller_contact.'</td>					
				</tr>
				<tr>
					<td style=" text-align: left;">Support Cont Person</td>
					<td style="text-align: left;">'.$supportContPerson.'</td>					
				</tr>
				<tr>
					<td style=" text-align: left;">Support Cont Number</td>
					<td style="text-align: left;">'.$supportContPersonMob.'</td>					
				</tr>
				<tr>  
					<td style=" text-align: left;">Response Date</td>
					<td style="text-align: left;">'.date("d-m-Y",strtotime($db_estimated_response_time)).'</td>					
				</tr>
				<tr>  
					<td style=" text-align: left;">Response Time</td>
					<td style="text-align: left;">'.date("H:i:s",strtotime($db_estimated_response_time)).'</td>					
				</tr>
				<tr>  
					<td style=" text-align: left;">Restoration Date</td>
					<td style="text-align: left;">'.date("d-m-Y",strtotime($db_tat_scheduled)).'</td>					
				</tr>
				<tr>  
					<td style=" text-align: left;">Restoration Time</td>
					<td style="text-align: left;">'.date("H:i:s",strtotime($db_tat_scheduled)).'</td>					
				</tr>
				<tr>
					<td style=" text-align: left;">Comments</td>
					<td style="text-align: left;">';
					for($i=0;$i<sizeof($assign_remark_log);$i++){
						$date = date('d-m-Y H:i:s',strtotime($assign_remark_date_log[$i]));
						$body .= $date.' : '.$assign_remark_log[$i].'<br>';
					}					
					$body .='</td>					
				</tr>
				
				<tr>
					
				</tr>
			</table>
					<p>Thank You,</p>
					<p>CMS System Team</p>
					<br/><p style="text-decoration: underline;">Note:</p>
					<p>This is a system generated email, please do not reply</p>';
					$data=['body'=>$body];
					/* $toUserArr = $toUserArr!=''?$toUserArr:'test@dispostable.com';
					$ccUserArr = $ccUserArr!=''?$ccUserArr:'test@dispostable.com'; */
					//dd($toUserArr);
					Mail::send('assigned_email',["data"=>$data],function ($message) use ($toUserArr, $ccUserArr, $subject) {
						$message->to($toUserArr)->cc($ccUserArr)->bcc(['ashutosh.rawat@cogenteservices.in','madhur.bhati@cogenteservices.com','Panchakarla.SaiPra@ashokleyland.com'])->subject($subject);
						$message->from('select.support@ashokleyland.com');
					});
					
					DB::table('escaltion_levels')->where('complaint_number', $complaint_number)->update(['levels' => $level,'updated_at'=>"$currentDateTime"]);
					DB::table('escalation_log')->insert(['level'=>$level,'complaint_number'=>$complaint_number,'to_user'=>implode(",",$toUserArr),'cc_user'=>implode(",",$ccUserArr),'subject'=>$subject,'body'=>$body]);
				}
				

			}
			
			

			


		}
		
	}
}	 